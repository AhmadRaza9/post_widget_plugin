console.log("gaming-place.js");
