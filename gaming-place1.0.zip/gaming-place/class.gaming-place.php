<?php

class Gaming_Widget extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            false, // Base ID
            __('Gaming Products Widget', 'text_domain'), // Name
            array('description' => __('The Gaming Place widget', 'text_domain')),
        );

    }

    // Creating widget front-end
    public function widget($args, $instance)
    {
        $title = apply_filters('My-Widget', $instance['title']);
        $text = apply_filters('My-Widget', $instance['text']);
        $image = apply_filters('My-Widget', $instance['image']);

        if (!empty($title)) {
            echo $args['before_widget'];

            echo "<h4 class='cw_title_" . str_replace(' ', '_', substr($title, 0, 5)) . "'>" . $title . "</h4>";
            echo "<p class='cw_description'>$text</p>";
            echo "<img class='cw_image' src='$image'>";
            echo $args['after_widget'];

        }
    }

    // Creating widget Backend
    public function form($instance)
    {
        if (isset($instance['title']) && isset($instance['text']) && isset($instance['image'])) {
            $title = $instance['title'];
            $text = $instance['text'];
            $image = $instance['image'];

        } else {
            $title = __('New title', 'wpb_widget_domain');
        }
        ?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:');?></label>
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" placeholder="Enter Title" />
                <label for="<?php echo $this->get_field_id('image'); ?>"><?php _e('Image:');?></label>
                <input class="widefat" id="<?php echo $this->get_field_id('image'); ?>" name="<?php echo $this->get_field_name('image'); ?>" type="text" value="<?php echo esc_attr($image); ?>" placeholder="Enter Image URL">
                <label for="<?php echo $this->get_field_id('text'); ?>"><?php _e('Description:');?></label><br>
                <textarea class="widefat" name="<?php echo $this->get_field_name('text'); ?>" id="<?php echo $this->get_field_id('text'); ?>" cols="57" rows="5" placeholder="Enter Description"><?php echo esc_attr($text); ?></textarea>
            </p>
            <?php
}

    // Updating widget replacing old instances with new
    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['text'] = (!empty($new_instance['text'])) ? strip_tags($new_instance['text']) : '';
        $instance['image'] = (!empty($new_instance['image'])) ? strip_tags($new_instance['image']) : '';
        return $instance;
    }

}
