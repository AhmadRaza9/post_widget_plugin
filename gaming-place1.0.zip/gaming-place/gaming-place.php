<?php

/**
 * Plugin Name: Gaming Products
 * Description: Gaming Place Products
 * Version: 1.0
 * Author: Ahmad Raza
 * Author URI: http://ahmadraza.ga/
 * License: GPL2
 **/

include "class.gaming-place.php";

function register_Gaming_widget()
{
    wp_enqueue_script('gp-scripts', plugins_url() . '/gaming-place/js/custom.js', array('jquery'), '1.0.0', false);

    wp_enqueue_style('gp_custom_css', plugins_url() . '/gaming-place/css/custom.css');

    register_widget('Gaming_Widget');
}
add_action('widgets_init', 'register_Gaming_widget');
